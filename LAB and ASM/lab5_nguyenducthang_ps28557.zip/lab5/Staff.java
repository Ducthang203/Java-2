/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab5;

import java.io.Serializable;

/**
 *
 * @author teo
 */
public class Staff implements Serializable{
    public String fullname;
    public double salary;
}
