
package lab7;
import java.util.*;

/**
 *
 * @author 84387
 */
public class bai1 {
    
}
