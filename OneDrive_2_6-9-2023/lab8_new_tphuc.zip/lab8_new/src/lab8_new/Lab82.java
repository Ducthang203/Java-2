/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8;

import java.util.ArrayList;
import java.util.Scanner;


public class Lab82 {
    public static void main(String[] args) {
         ArrayList<Integer> myarr = new ArrayList<>();
        Scanner nhap = new Scanner(System.in);
        int i=0;
        System.out.println("Nhap tu 1 toi 10");
        while(i<=9){
            myarr.add(nhap.nextInt());
            i++;
        }
        System.out.println("Cac so da nhap");
        i=0;
        do{
           System.out.println(myarr.get(i));
           i++;
        }while(i<=9);
    }
    
}
