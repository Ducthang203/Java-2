/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8;

import java.util.ArrayList;


public class Lab81 {
    public static void main(String[] args) {
        ArrayList mylist = new ArrayList();
        mylist.add(10);
        mylist.add(5.55);
        mylist.add(true);
        mylist.add("Hello");
        //System.out.println(mylist);
        int a = (Integer)mylist.get(0);
        double b = (Double)mylist.get(1);
        boolean tf = (boolean)mylist.get(2);
        String s = (String)mylist.get(3);
        System.out.print(a);
        System.out.println();
        System.out.print(b);
        System.out.println();
        System.out.print(tf);
        System.out.println();
        System.out.print(s);
    }
    
}
